import { type FormEvent, type ReactNode, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  ArrowDownRight,
  ArrowUpRight,
  Building2,
  CheckCircle2,
  ChevronRight,
  Clock3,
  Compass,
  ExternalLink,
  FileCheck2,
  Handshake,
  Home as HomeIcon,
  LandPlot,
  Mail,
  MapPin,
  Menu,
  MessageCircle,
  Phone,
  Quote,
  Send,
  ShieldCheck,
  Star,
  X,
} from 'lucide-react';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

const ASSETS = {
  logo: '/assets/WhatsApp_Image_2026-08-29_at_7.36.32_PM_1788012572887.jpeg',
  rohit: '/assets/WhatsApp_Image_2026-08-29_at_7.36.32_PM_(1)_1788012581425.jpeg',
  smartPlots: '/assets/WhatsApp_Image_2026-08-29_at_7.36.33_PM_1788012587968.jpeg',
  team: '/assets/WhatsApp_Image_2026-08-29_at_7.36.33_PM_(1)_1788012595306.jpeg',
  future: '/assets/WhatsApp_Image_2026-08-29_at_7.36.34_PM_(1)_1788012625269.jpeg',
  reraCertificate: '/assets/rera-registration-certificate.jpeg',
};

const contactPhone = '+91 97141 14913';
const businessAddress = 'Sector 4, RP Real Estate, near Baucher Temple, Vivekandnagar, Hathijan, Ahmedabad, Gujarat 382445';
const phoneHref = 'tel:+919714114913';
const whatsappHref = 'https://wa.me/919714114913?text=Hello%20RP%20Real%20Estate%2C%20I%20would%20like%20to%20know%20more%20about%20your%20properties.';
const mapHref = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(businessAddress)}`;

function scrollToSection(id: string) {
  document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <a
      href="#top"
      className={`flex items-center gap-3 ${compact ? '' : 'group'}`}
      data-testid={compact ? 'link-footer-logo' : 'link-logo'}
      aria-label="RP Real Estate home"
    >
      <span className="h-12 w-12 overflow-hidden rounded-full border border-[hsl(var(--secondary)/.45)] bg-[hsl(var(--card))] p-1 shadow-sm">
        <img src={ASSETS.logo} alt="RP Real Estate logo" className="h-full w-full rounded-full object-cover" />
      </span>
      <span className="leading-none">
        <span className="block font-heading text-[15px] font-extrabold tracking-[.12em] text-[hsl(var(--primary))]">RP</span>
        <span className="mt-1 block text-[10px] font-bold uppercase tracking-[.18em] text-[hsl(var(--secondary))]">Real Estate</span>
      </span>
    </a>
  );
}

function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [interest, setInterest] = useState('Premium plots & properties');

  const closeMenu = () => setMenuOpen(false);
  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSubmitted(true);
    event.currentTarget.reset();
    setInterest('Premium plots & properties');
  };

  return (
    <main id="top" className="site-shell min-h-[100dvh]">
      <div className="topline hidden md:block">
        <div className="mx-auto flex max-w-[1240px] items-center justify-between px-6 py-2 text-[11px] font-medium tracking-wide lg:px-10">
          <span className="flex items-center gap-2"><span className="pulse-dot h-2 w-2 rounded-full bg-[hsl(var(--secondary))]" /> Open 24 hours · Local guidance, whenever you need it</span>
          <div className="flex items-center gap-5">
            <a href={phoneHref} data-testid="link-top-phone">{contactPhone}</a>
            <a href="mailto:contact.rprealestate@gmail.com" data-testid="link-top-email">contact.rprealestate@gmail.com</a>
          </div>
        </div>
      </div>

      <header className="nav-glass sticky top-0 z-40 border-b border-[hsl(var(--border)/.75)]">
        <div className="mx-auto flex max-w-[1240px] items-center justify-between px-5 py-3.5 lg:px-10">
          <Logo />
          <nav className="hidden items-center gap-7 md:flex" aria-label="Main navigation">
            <a className="text-xs font-bold uppercase tracking-[.1em] text-[hsl(var(--muted-foreground))] transition-colors hover:text-[hsl(var(--primary))]" href="#about" data-testid="link-nav-about">About us</a>
            <a className="text-xs font-bold uppercase tracking-[.1em] text-[hsl(var(--muted-foreground))] transition-colors hover:text-[hsl(var(--primary))]" href="#services" data-testid="link-nav-services">What we do</a>
            <a className="text-xs font-bold uppercase tracking-[.1em] text-[hsl(var(--muted-foreground))] transition-colors hover:text-[hsl(var(--primary))]" href="#areas" data-testid="link-nav-areas">Our areas</a>
            <a className="text-xs font-bold uppercase tracking-[.1em] text-[hsl(var(--muted-foreground))] transition-colors hover:text-[hsl(var(--primary))]" href="#registration" data-testid="link-nav-registration">RERA</a>
            <a className="text-xs font-bold uppercase tracking-[.1em] text-[hsl(var(--muted-foreground))] transition-colors hover:text-[hsl(var(--primary))]" href="#contact" data-testid="link-nav-contact">Contact</a>
          </nav>
          <div className="hidden items-center gap-2 sm:flex">
            <a href={whatsappHref} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full border border-[hsl(var(--border))] px-4 py-2.5 text-xs font-bold text-[hsl(var(--primary))] transition hover:border-[hsl(var(--secondary))] hover:bg-[hsl(var(--secondary)/.08)]" data-testid="link-nav-whatsapp">
              <MessageCircle className="h-4 w-4 text-[hsl(var(--secondary))]" /> WhatsApp
            </a>
            <button onClick={() => scrollToSection('contact')} className="inline-flex items-center gap-2 rounded-full bg-[hsl(var(--primary))] px-4 py-2.5 text-xs font-bold text-[hsl(var(--primary-foreground))] transition hover:bg-[hsl(var(--accent))]" data-testid="button-nav-inquiry">
              Talk to Rohit <ArrowUpRight className="h-4 w-4" />
            </button>
          </div>
          <button className="rounded-lg p-2 text-[hsl(var(--primary))] md:hidden" onClick={() => setMenuOpen(!menuOpen)} aria-label={menuOpen ? 'Close menu' : 'Open menu'} data-testid="button-mobile-menu">
            {menuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
        {menuOpen && (
          <div className="border-t border-[hsl(var(--border))] bg-[hsl(var(--background))] px-5 py-5 md:hidden">
            <nav className="flex flex-col gap-4" aria-label="Mobile navigation">
              <a href="#about" onClick={closeMenu} className="text-sm font-bold text-[hsl(var(--primary))]" data-testid="link-mobile-about">About us</a>
              <a href="#services" onClick={closeMenu} className="text-sm font-bold text-[hsl(var(--primary))]" data-testid="link-mobile-services">What we do</a>
              <a href="#areas" onClick={closeMenu} className="text-sm font-bold text-[hsl(var(--primary))]" data-testid="link-mobile-areas">Our areas</a>
              <a href="#registration" onClick={closeMenu} className="text-sm font-bold text-[hsl(var(--primary))]" data-testid="link-mobile-registration">RERA registration</a>
              <a href="#contact" onClick={closeMenu} className="text-sm font-bold text-[hsl(var(--primary))]" data-testid="link-mobile-contact">Contact</a>
              <a href={phoneHref} onClick={closeMenu} className="mt-1 inline-flex w-fit items-center gap-2 rounded-full bg-[hsl(var(--primary))] px-4 py-3 text-sm font-bold text-[hsl(var(--primary-foreground))]" data-testid="link-mobile-call"><Phone className="h-4 w-4" /> Call {contactPhone}</a>
            </nav>
          </div>
        )}
      </header>

      <section className="hero-grid relative overflow-hidden">
        <div className="hero-wash absolute inset-0 z-0" />
        <div className="relative z-10 mx-auto grid min-h-[650px] max-w-[1240px] items-center gap-12 px-5 py-16 lg:grid-cols-[1.02fr_.98fr] lg:px-10 lg:py-24">
          <div className="reveal max-w-[620px]">
            <div className="mb-6 flex items-center gap-3 text-[11px] font-bold uppercase tracking-[.2em] text-[hsl(var(--accent))]">
              <span className="gold-rule" /> Hathijan · Ahmedabad
            </div>
            <h1 className="font-display text-[clamp(3.35rem,8vw,6.9rem)] leading-[.94] tracking-[-.055em] text-[hsl(var(--primary))]">
              Find your<br /><span className="text-[hsl(var(--accent))]">next ground.</span>
            </h1>
            <p className="mt-7 max-w-[485px] text-[17px] leading-8 text-[hsl(var(--muted-foreground))]">
              Straightforward property guidance for the places around Ahmedabad where people are building, growing and planning ahead.
            </p>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row">
              <button onClick={() => scrollToSection('contact')} className="inline-flex items-center justify-center gap-3 rounded-full bg-[hsl(var(--primary))] px-6 py-3.5 text-sm font-bold text-[hsl(var(--primary-foreground))] shadow-[0_8px_20px_hsl(var(--primary)/.16)] transition hover:bg-[hsl(var(--accent))]" data-testid="button-hero-inquiry">
                Start a conversation <ArrowUpRight className="h-4 w-4" />
              </button>
              <a href={whatsappHref} target="_blank" rel="noreferrer" className="inline-flex items-center justify-center gap-3 rounded-full border border-[hsl(var(--primary)/.2)] bg-[hsl(var(--card)/.68)] px-6 py-3.5 text-sm font-bold text-[hsl(var(--primary))] transition hover:border-[hsl(var(--secondary))] hover:bg-[hsl(var(--secondary)/.12)]" data-testid="link-hero-whatsapp">
                <MessageCircle className="h-4 w-4 text-[hsl(var(--secondary))]" /> WhatsApp Rohit
              </a>
            </div>
            <div className="mt-10 flex flex-wrap items-center gap-x-7 gap-y-3 border-t border-[hsl(var(--border))] pt-5 text-xs font-semibold text-[hsl(var(--muted-foreground))]">
              <span className="flex items-center gap-2"><Star className="h-4 w-4 fill-[hsl(var(--secondary))] text-[hsl(var(--secondary))]" /> 4.6/5 on Google</span>
              <span className="flex items-center gap-2"><Clock3 className="h-4 w-4 text-[hsl(var(--secondary))]" /> Open 24 hours</span>
              <span className="flex items-center gap-2"><MapPin className="h-4 w-4 text-[hsl(var(--secondary))]" /> Vivekandnagar, Hathijan</span>
            </div>
          </div>

          <div className="reveal reveal-delay-2 relative mx-auto w-full max-w-[535px] lg:ml-auto">
            <div className="image-frame relative aspect-[.88] overflow-hidden rounded-[2rem] border-8 border-[hsl(var(--card)/.75)] bg-[hsl(var(--muted))]">
              <img src={ASSETS.team} alt="The RP Real Estate team together" className="h-full w-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-[hsl(var(--primary)/.65)] via-transparent to-transparent" />
              <div className="absolute bottom-6 left-6 right-6 flex items-end justify-between gap-4 text-[hsl(var(--primary-foreground))]">
                <div>
                  <p className="font-heading text-lg font-extrabold">Local people. Clear direction.</p>
                  <p className="mt-1 text-xs text-[hsl(var(--primary-foreground)/.72)]">A team that picks up the phone.</p>
                </div>
                <span className="rounded-full bg-[hsl(var(--secondary))] p-3 text-[hsl(var(--primary))]"><ArrowDownRight className="h-5 w-5" /></span>
              </div>
            </div>
            <div className="absolute -bottom-5 -left-4 hidden w-44 rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-4 editorial-shadow sm:block">
              <p className="font-display text-3xl text-[hsl(var(--primary))]">RP</p>
              <p className="mt-1 text-[10px] font-bold uppercase tracking-[.14em] text-[hsl(var(--muted-foreground))]">Your local property desk</p>
            </div>
          </div>
        </div>
      </section>

      <div className="overflow-hidden border-y border-[hsl(var(--border))] bg-[hsl(var(--secondary))] py-3.5 text-[hsl(var(--primary))]">
        <div className="marquee-track flex w-max items-center gap-8 whitespace-nowrap text-[11px] font-extrabold uppercase tracking-[.18em]">
          <span>Smart plots</span><span className="h-1 w-1 rounded-full bg-[hsl(var(--primary)/.55)]" /><span>Future-ready locations</span><span className="h-1 w-1 rounded-full bg-[hsl(var(--primary)/.55)]" /><span>Documentation guidance</span><span className="h-1 w-1 rounded-full bg-[hsl(var(--primary)/.55)]" /><span>Ahmedabad & nearby areas</span><span className="h-1 w-1 rounded-full bg-[hsl(var(--primary)/.55)]" /><span>Smart plots</span><span className="h-1 w-1 rounded-full bg-[hsl(var(--primary)/.55)]" /><span>Future-ready locations</span><span className="h-1 w-1 rounded-full bg-[hsl(var(--primary)/.55)]" /><span>Documentation guidance</span><span className="h-1 w-1 rounded-full bg-[hsl(var(--primary)/.55)]" /><span>Ahmedabad & nearby areas</span>
        </div>
      </div>

      <section id="about" className="section-anchor mx-auto max-w-[1240px] px-5 py-24 lg:px-10 lg:py-32">
        <div className="grid gap-14 lg:grid-cols-[.9fr_1.1fr] lg:items-start">
          <div>
            <div className="mb-5 flex items-center gap-3 text-[11px] font-bold uppercase tracking-[.2em] text-[hsl(var(--accent))]"><span className="gold-rule" /> The RP approach</div>
            <h2 className="font-display text-[clamp(2.6rem,5vw,4.6rem)] leading-[1.02] tracking-[-.045em] text-[hsl(var(--primary))]">Property decisions<br /><span className="text-[hsl(var(--accent))]">should feel clear.</span></h2>
            <p className="mt-7 max-w-[440px] text-base leading-8 text-[hsl(var(--muted-foreground))]">Buying land or a home is a meaningful step. We make the process more practical: understand the location, ask the right questions, and move forward with someone who stays available.</p>
            <a href="#contact" className="mt-7 inline-flex items-center gap-2 text-sm font-extrabold text-[hsl(var(--primary))] underline decoration-[hsl(var(--secondary))] decoration-2 underline-offset-8" data-testid="link-about-contact">Meet the team <ChevronRight className="h-4 w-4" /></a>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-6 hover-lift">
              <span className="mb-12 flex h-11 w-11 items-center justify-center rounded-xl bg-[hsl(var(--secondary)/.18)] text-[hsl(var(--accent))]"><Compass className="h-5 w-5" /></span>
              <h3 className="font-heading text-lg font-extrabold text-[hsl(var(--primary))]">Local, not distant</h3>
              <p className="mt-2 text-sm leading-6 text-[hsl(var(--muted-foreground))]">We know the neighbourhoods and the questions local buyers actually ask.</p>
            </div>
            <div className="mt-0 rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--primary))] p-6 text-[hsl(var(--primary-foreground))] hover-lift sm:mt-12">
              <span className="mb-12 flex h-11 w-11 items-center justify-center rounded-xl bg-[hsl(var(--secondary))] text-[hsl(var(--primary))]"><Handshake className="h-5 w-5" /></span>
              <h3 className="font-heading text-lg font-extrabold">Responsive by nature</h3>
              <p className="mt-2 text-sm leading-6 text-[hsl(var(--primary-foreground)/.68)]">From first call to site visit, practical support without passing you around.</p>
            </div>
            <div className="rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-6 hover-lift">
              <span className="mb-12 flex h-11 w-11 items-center justify-center rounded-xl bg-[hsl(var(--accent)/.13)] text-[hsl(var(--accent))]"><ShieldCheck className="h-5 w-5" /></span>
              <h3 className="font-heading text-lg font-extrabold text-[hsl(var(--primary))]">Thoughtful guidance</h3>
              <p className="mt-2 text-sm leading-6 text-[hsl(var(--muted-foreground))]">A careful conversation around documents, use and long-term intent.</p>
            </div>
            <div className="mt-0 rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-6 hover-lift sm:mt-12">
              <span className="mb-12 flex h-11 w-11 items-center justify-center rounded-xl bg-[hsl(var(--secondary)/.18)] text-[hsl(var(--accent))]"><Building2 className="h-5 w-5" /></span>
              <h3 className="font-heading text-lg font-extrabold text-[hsl(var(--primary))]">Built around your plan</h3>
              <p className="mt-2 text-sm leading-6 text-[hsl(var(--muted-foreground))]">Home, plot or future development: start with what you want the property to do.</p>
            </div>
          </div>
        </div>
      </section>

      <section id="services" className="section-anchor bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]">
        <div className="mx-auto max-w-[1240px] px-5 py-24 lg:px-10 lg:py-32">
          <div className="grid gap-12 lg:grid-cols-[.75fr_1.25fr]">
            <div>
              <div className="mb-5 flex items-center gap-3 text-[11px] font-bold uppercase tracking-[.2em] text-[hsl(var(--secondary))]"><span className="gold-rule" /> How we help</div>
              <h2 className="font-display text-[clamp(2.7rem,5vw,4.7rem)] leading-[1.02] tracking-[-.045em]">Good property work<br /><span className="text-[hsl(var(--secondary))]">starts before the visit.</span></h2>
              <p className="mt-7 max-w-[390px] text-base leading-8 text-[hsl(var(--primary-foreground)/.66)]">Our role is to add context at every step, so you can make decisions with a little more confidence.</p>
              <a href={phoneHref} className="mt-8 inline-flex items-center gap-3 rounded-full border border-[hsl(var(--primary-foreground)/.25)] px-5 py-3 text-sm font-bold transition hover:border-[hsl(var(--secondary))] hover:text-[hsl(var(--secondary))]" data-testid="link-services-call"><Phone className="h-4 w-4" /> Call the property desk</a>
            </div>
            <div className="divide-y divide-[hsl(var(--primary-foreground)/.15)] border-y border-[hsl(var(--primary-foreground)/.15)]">
              {[
                { icon: LandPlot, n: '01', title: 'Premium plots & properties', text: 'Explore opportunities across Hathijan, Nikol, Naroda, Ahmedabad, Bhareja, Dakor and nearby areas based on your plans.' },
                { icon: Compass, n: '02', title: 'Future-development opportunities', text: 'Understand locations positioned for future growth without relying on rushed promises or guesswork.' },
                { icon: FileCheck2, n: '03', title: 'Documentation guidance', text: 'Know what to ask, which details to review and when to seek the right professional advice.' },
                { icon: HomeIcon, n: '04', title: 'Home loans & DSA assistance', text: 'Loan assistance through DSA for applications with HDFC Bank, PMB Bank, ICICI Bank, Shubham Bank and Axis Bank.' },
              ].map(({ icon: Icon, n, title, text }) => (
                <div key={n} className="group flex gap-5 py-7 transition hover:bg-[hsl(var(--primary-foreground)/.04)] sm:gap-7">
                  <span className="font-mono text-xs text-[hsl(var(--secondary))]">{n}</span>
                  <Icon className="mt-0.5 h-5 w-5 shrink-0 text-[hsl(var(--secondary))]" />
                  <div className="flex-1">
                    <h3 className="font-heading text-lg font-extrabold">{title}</h3>
                    <p className="mt-2 max-w-[520px] text-sm leading-6 text-[hsl(var(--primary-foreground)/.62)]">{text}</p>
                  </div>
                  <ArrowUpRight className="h-5 w-5 shrink-0 text-[hsl(var(--primary-foreground)/.32)] transition group-hover:text-[hsl(var(--secondary))]" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section id="registration" className="section-anchor border-y border-[hsl(var(--border))] bg-[hsl(var(--muted)/.42)]">
        <div className="mx-auto grid max-w-[1240px] items-center gap-10 px-5 py-20 lg:grid-cols-[.9fr_1.1fr] lg:px-10 lg:py-24">
          <div>
            <div className="mb-5 flex items-center gap-3 text-[11px] font-bold uppercase tracking-[.2em] text-[hsl(var(--accent))]"><span className="gold-rule" /> Registration</div>
            <h2 className="font-display text-[clamp(2.7rem,5vw,4.7rem)] leading-[1.02] tracking-[-.045em] text-[hsl(var(--primary))]">Registered with<br /><span className="text-[hsl(var(--accent))]">Gujarat RERA.</span></h2>
            <p className="mt-6 max-w-[470px] text-base leading-8 text-[hsl(var(--muted-foreground))]">View the RP Real Estate agent registration certificate issued by the Gujarat Real Estate Regulatory Authority.</p>
            <a href={ASSETS.reraCertificate} target="_blank" rel="noreferrer" className="mt-7 inline-flex items-center gap-2 rounded-full bg-[hsl(var(--primary))] px-5 py-3 text-sm font-bold text-[hsl(var(--primary-foreground))] transition hover:bg-[hsl(var(--accent))]" data-testid="link-rera-certificate">View certificate full size <ExternalLink className="h-4 w-4" /></a>
          </div>
          <div className="overflow-hidden rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-3 shadow-sm" data-testid="image-rera-certificate">
            <iframe src={ASSETS.reraCertificate} title="RP Real Estate Gujarat RERA registration certificate" width={960} height={1280} className="mx-auto block aspect-[3/4] w-full max-w-[480px] overflow-hidden rounded-xl border-0" />
          </div>
        </div>
      </section>

      <section id="areas" className="section-anchor mx-auto max-w-[1240px] px-5 py-24 lg:px-10 lg:py-32">
        <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div>
            <div className="mb-5 flex items-center gap-3 text-[11px] font-bold uppercase tracking-[.2em] text-[hsl(var(--accent))]"><span className="gold-rule" /> The local lens</div>
            <h2 className="font-display text-[clamp(2.7rem,5vw,4.7rem)] leading-[1.02] tracking-[-.045em] text-[hsl(var(--primary))]">Places with a<br /><span className="text-[hsl(var(--accent))]">plan in motion.</span></h2>
          </div>
          <p className="max-w-[330px] text-sm leading-7 text-[hsl(var(--muted-foreground))]">Start with the area that matters to you. We will help you understand the opportunity, the practicalities and the next step.</p>
        </div>
        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[
            { name: 'Hathijan', note: 'Our home base', tone: 'bg-[hsl(var(--secondary)/.16)]' },
            { name: 'Nikol', note: 'Connected & active', tone: 'bg-[hsl(var(--accent)/.12)]' },
            { name: 'Naroda', note: 'Industrial momentum', tone: 'bg-[hsl(var(--primary)/.08)]' },
            { name: 'Ahmedabad', note: 'The wider picture', tone: 'bg-[hsl(var(--secondary)/.24)]' },
            { name: 'Bhareja', note: 'Property guidance', tone: 'bg-[hsl(var(--accent)/.12)]' },
            { name: 'Dakor', note: 'Property guidance', tone: 'bg-[hsl(var(--secondary)/.16)]' },
          ].map((area, index) => (
            <button onClick={() => { setInterest(`${area.name} property enquiry`); scrollToSection('contact'); }} key={area.name} className={`group relative min-h-44 overflow-hidden rounded-2xl border border-[hsl(var(--border))] ${area.tone} p-6 text-left transition hover:-translate-y-1 hover:border-[hsl(var(--secondary))]`} data-testid={`button-area-${index + 1}`}>
              <span className="absolute -right-4 -top-8 font-display text-[120px] leading-none text-[hsl(var(--primary)/.08)]">{String(index + 1).padStart(2, '0')}</span>
              <MapPin className="h-5 w-5 text-[hsl(var(--accent))]" />
              <div className="absolute bottom-6 left-6 right-6 flex items-end justify-between">
                <span><strong className="block font-heading text-xl font-extrabold text-[hsl(var(--primary))]">{area.name}</strong><small className="mt-1 block text-xs font-semibold text-[hsl(var(--muted-foreground))]">{area.note}</small></span>
                <span className="rounded-full bg-[hsl(var(--card)/.8)] p-2 text-[hsl(var(--primary))] transition group-hover:bg-[hsl(var(--secondary))]"><ArrowUpRight className="h-4 w-4" /></span>
              </div>
            </button>
          ))}
        </div>
      </section>

      <section className="border-y border-[hsl(var(--border))] bg-[hsl(var(--muted)/.42)]">
        <div className="mx-auto grid max-w-[1240px] gap-0 px-5 py-20 lg:grid-cols-[.8fr_1.2fr] lg:px-10 lg:py-24">
          <div className="relative min-h-[430px] overflow-hidden rounded-t-[1.75rem] bg-[hsl(var(--primary))] lg:rounded-l-[1.75rem] lg:rounded-tr-none">
            <img src={ASSETS.rohit} alt="Rohit from RP Real Estate" className="absolute inset-0 h-full w-full object-cover object-top opacity-90 mix-blend-normal" />
            <div className="absolute inset-0 bg-gradient-to-t from-[hsl(var(--primary)/.88)] via-transparent to-transparent" />
            <div className="absolute bottom-7 left-7 text-[hsl(var(--primary-foreground))]">
              <p className="font-display text-4xl">Rohit</p>
              <p className="mt-1 text-xs font-bold uppercase tracking-[.18em] text-[hsl(var(--secondary))]">Your first call at RP</p>
            </div>
          </div>
          <div className="flex flex-col justify-center rounded-b-[1.75rem] bg-[hsl(var(--card))] p-8 lg:rounded-b-none lg:rounded-r-[1.75rem] lg:p-14">
            <div className="mb-5 flex items-center gap-3 text-[11px] font-bold uppercase tracking-[.2em] text-[hsl(var(--accent))]"><span className="gold-rule" /> The person behind the phone</div>
            <h2 className="font-display text-[clamp(2.4rem,4vw,4rem)] leading-[1.06] tracking-[-.04em] text-[hsl(var(--primary))]">A familiar face<br />makes a difference.</h2>
            <p className="mt-6 max-w-[510px] text-base leading-8 text-[hsl(var(--muted-foreground))]">Rohit and the RP Real Estate team keep things personal. Call with a rough idea, a location in mind or simply a question. We will listen first, then help you work out what makes sense.</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a href={phoneHref} className="inline-flex items-center gap-2 rounded-full bg-[hsl(var(--primary))] px-5 py-3 text-sm font-bold text-[hsl(var(--primary-foreground))] transition hover:bg-[hsl(var(--accent))]" data-testid="link-rohit-call"><Phone className="h-4 w-4" /> Call Rohit</a>
              <a href="mailto:contact.rprealestate@gmail.com" className="inline-flex items-center gap-2 rounded-full border border-[hsl(var(--border))] px-5 py-3 text-sm font-bold text-[hsl(var(--primary))] transition hover:border-[hsl(var(--secondary))]" data-testid="link-rohit-email"><Mail className="h-4 w-4" /> Send an email</a>
            </div>
          </div>
        </div>
      </section>

      <section id="stories" className="section-anchor mx-auto max-w-[1240px] px-5 py-24 lg:px-10 lg:py-32">
        <div className="grid gap-12 lg:grid-cols-[1fr_.9fr] lg:items-center">
          <div className="grid grid-cols-[1.05fr_.95fr] gap-4">
            <img src={ASSETS.smartPlots} alt="Gujarati smart plot campaign creative" className="h-[390px] w-full rounded-2xl object-cover object-center shadow-sm" />
            <div className="space-y-4 pt-12">
              <img src={ASSETS.future} alt="Gujarati future-development campaign creative" className="h-[250px] w-full rounded-2xl object-cover object-top shadow-sm" />
              <p className="px-2 text-[10px] font-bold uppercase leading-5 tracking-[.14em] text-[hsl(var(--muted-foreground))]">Real conversations. Real local context.</p>
            </div>
          </div>
          <div>
            <div className="mb-5 flex items-center gap-3 text-[11px] font-bold uppercase tracking-[.2em] text-[hsl(var(--accent))]"><span className="gold-rule" /> From our campaigns</div>
            <h2 className="font-display text-[clamp(2.7rem,5vw,4.6rem)] leading-[1.03] tracking-[-.045em] text-[hsl(var(--primary))]">Think beyond<br /><span className="text-[hsl(var(--accent))]">today's address.</span></h2>
            <p className="mt-6 text-base leading-8 text-[hsl(var(--muted-foreground))]">Our smart plot and future-development campaigns are a reminder to look at the full picture: where a place is, what surrounds it and how it fits your plans.</p>
            <button onClick={() => { setInterest('Future-development opportunity'); scrollToSection('contact'); }} className="mt-8 inline-flex items-center gap-2 text-sm font-extrabold text-[hsl(var(--primary))] underline decoration-[hsl(var(--secondary))] decoration-2 underline-offset-8" data-testid="button-stories-inquiry">Ask about an opportunity <ArrowUpRight className="h-4 w-4" /></button>
          </div>
        </div>
      </section>

      <section className="bg-[hsl(var(--secondary))]">
        <div className="mx-auto max-w-[1240px] px-5 py-20 lg:px-10 lg:py-24">
          <div className="flex flex-col justify-between gap-8 md:flex-row md:items-end">
            <div>
              <div className="mb-5 flex items-center gap-3 text-[11px] font-bold uppercase tracking-[.2em] text-[hsl(var(--primary)/.68)]"><span className="h-[3px] w-[52px] bg-[hsl(var(--primary))]" /> Words from customers</div>
              <h2 className="font-display text-[clamp(2.7rem,5vw,4.6rem)] leading-[1.03] tracking-[-.045em] text-[hsl(var(--primary))]">The simple things<br />matter most.</h2>
            </div>
            <div className="flex items-center gap-3 text-[hsl(var(--primary))]"><span className="font-heading text-4xl font-extrabold">4.6</span><span className="border-l border-[hsl(var(--primary)/.25)] pl-3 text-xs font-bold leading-5">Google rating<br />9 reviews</span></div>
          </div>
          <div className="mt-12 grid gap-4 md:grid-cols-3">
            {[
              { quote: 'Good service rohit bhai', name: 'Google customer' },
              { quote: 'Good work Rohit sir', name: 'Google customer' },
              { quote: 'Home loan process was convenient. The team supported us well.', name: 'Home-loan customer' },
            ].map((item, index) => (
              <div key={item.quote} className={`rounded-2xl border border-[hsl(var(--primary)/.16)] p-7 ${index === 2 ? 'bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]' : 'bg-[hsl(var(--secondary)/.45)] text-[hsl(var(--primary))]'}`}>
                <Quote className="h-7 w-7 opacity-60" />
                <p className="mt-10 min-h-16 font-display text-2xl leading-[1.2]">“{item.quote}”</p>
                <p className="mt-8 text-xs font-bold uppercase tracking-[.14em] opacity-60">{item.name}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="contact" className="section-anchor mx-auto max-w-[1240px] px-5 py-24 lg:px-10 lg:py-32">
        <div className="grid gap-12 lg:grid-cols-[.85fr_1.15fr]">
          <div>
            <div className="mb-5 flex items-center gap-3 text-[11px] font-bold uppercase tracking-[.2em] text-[hsl(var(--accent))]"><span className="gold-rule" /> Come by or call</div>
            <h2 className="font-display text-[clamp(2.9rem,5vw,5rem)] leading-[1.01] tracking-[-.05em] text-[hsl(var(--primary))]">Let’s talk<br /><span className="text-[hsl(var(--accent))]">property.</span></h2>
            <p className="mt-7 max-w-[400px] text-base leading-8 text-[hsl(var(--muted-foreground))]">Tell us what you are looking for. A quick note is enough to start — Rohit or a member of the RP team will get back to you.</p>
            <div className="mt-9 space-y-5">
              <a href={phoneHref} className="flex items-start gap-4 text-sm font-bold text-[hsl(var(--primary))]" data-testid="link-contact-phone"><span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[hsl(var(--secondary)/.2)] text-[hsl(var(--accent))]"><Phone className="h-4 w-4" /></span><span><span className="block text-xs font-medium text-[hsl(var(--muted-foreground))]">Call or WhatsApp</span><span className="mt-1 block">{contactPhone}</span></span></a>
              <a href="mailto:contact.rprealestate@gmail.com" className="flex items-start gap-4 text-sm font-bold text-[hsl(var(--primary))]" data-testid="link-contact-email"><span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[hsl(var(--secondary)/.2)] text-[hsl(var(--accent))]"><Mail className="h-4 w-4" /></span><span><span className="block text-xs font-medium text-[hsl(var(--muted-foreground))]">Email us</span><span className="mt-1 block break-all">contact.rprealestate@gmail.com</span></span></a>
              <a href={mapHref} target="_blank" rel="noreferrer" className="flex items-start gap-4 text-sm font-bold text-[hsl(var(--primary))]" data-testid="link-contact-map"><span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[hsl(var(--secondary)/.2)] text-[hsl(var(--accent))]"><MapPin className="h-4 w-4" /></span><span><span className="block text-xs font-medium text-[hsl(var(--muted-foreground))]">Visit the office</span><span className="mt-1 block max-w-[300px] leading-6">{businessAddress}</span></span><ExternalLink className="mt-1 h-4 w-4 shrink-0 text-[hsl(var(--muted-foreground))]" /></a>
            </div>
          </div>
          <div className="rounded-[1.75rem] border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-6 editorial-shadow sm:p-9">
            {submitted ? (
              <div className="flex min-h-[430px] flex-col items-center justify-center text-center">
                <span className="flex h-16 w-16 items-center justify-center rounded-full bg-[hsl(var(--secondary)/.18)] text-[hsl(var(--accent))]"><CheckCircle2 className="h-8 w-8" /></span>
                <h3 className="mt-6 font-display text-4xl text-[hsl(var(--primary))]">We’ve got your note.</h3>
                <p className="mt-4 max-w-[360px] text-sm leading-7 text-[hsl(var(--muted-foreground))]">Thank you for reaching out. Rohit or the RP Real Estate team will connect with you soon.</p>
                <button onClick={() => setSubmitted(false)} className="mt-8 rounded-full border border-[hsl(var(--border))] px-5 py-3 text-sm font-bold text-[hsl(var(--primary))] transition hover:border-[hsl(var(--secondary))]" data-testid="button-new-inquiry">Send another enquiry</button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="mb-7">
                  <p className="text-xs font-bold uppercase tracking-[.16em] text-[hsl(var(--accent))]">A quick enquiry</p>
                  <h3 className="mt-2 font-heading text-2xl font-extrabold text-[hsl(var(--primary))]">What can we help you explore?</h3>
                </div>
                <div className="grid gap-5 sm:grid-cols-2">
                  <label className="block"><span className="mb-2 block text-xs font-bold text-[hsl(var(--primary))]">Your name</span><input required name="name" className="field" placeholder="Tell us your name" data-testid="input-inquiry-name" /></label>
                  <label className="block"><span className="mb-2 block text-xs font-bold text-[hsl(var(--primary))]">Phone number</span><input required name="phone" type="tel" className="field" placeholder="+91" data-testid="input-inquiry-phone" /></label>
                </div>
                <label className="block"><span className="mb-2 block text-xs font-bold text-[hsl(var(--primary))]">I’m interested in</span><select value={interest} onChange={(event) => setInterest(event.target.value)} name="interest" className="field" data-testid="select-inquiry-interest"><option>Premium plots & properties</option><option>Future-development opportunity</option><option>Documentation guidance</option><option>Home-loan & DSA assistance</option><option>Property in Hathijan</option><option>Property in Nikol or Naroda</option><option>Property in Ahmedabad</option><option>Property in Bhareja</option><option>Property in Dakor</option></select></label>
                <label className="block"><span className="mb-2 block text-xs font-bold text-[hsl(var(--primary))]">Anything we should know?</span><textarea name="message" rows={4} className="field resize-none" placeholder="Area, timeline or a question on your mind" data-testid="textarea-inquiry-message" /></label>
                <button type="submit" className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-[hsl(var(--primary))] px-6 py-3.5 text-sm font-bold text-[hsl(var(--primary-foreground))] transition hover:bg-[hsl(var(--accent))]" data-testid="button-submit-inquiry"><Send className="h-4 w-4" /> Send enquiry</button>
                <p className="text-center text-[11px] leading-5 text-[hsl(var(--muted-foreground))]">Your details stay with the RP Real Estate team and are used to respond to this enquiry.</p>
              </form>
            )}
          </div>
        </div>
      </section>

      <footer className="bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]">
        <div className="mx-auto grid max-w-[1240px] gap-10 px-5 py-14 lg:grid-cols-[1.2fr_.8fr_.8fr] lg:px-10">
          <div>
            <Logo compact />
            <p className="mt-6 max-w-[310px] text-sm leading-7 text-[hsl(var(--primary-foreground)/.62)]">A responsive local property team for buyers, land investors and home-loan customers in and around Ahmedabad.</p>
            <a href="https://rprealestate.in" target="_blank" rel="noreferrer" className="mt-5 inline-flex items-center gap-2 text-xs font-bold text-[hsl(var(--secondary))]" data-testid="link-footer-website">rprealestate.in <ExternalLink className="h-3.5 w-3.5" /></a>
          </div>
          <div>
            <h3 className="text-xs font-bold uppercase tracking-[.16em] text-[hsl(var(--secondary))]">Explore</h3>
            <div className="mt-5 flex flex-col gap-3 text-sm text-[hsl(var(--primary-foreground)/.68)]">
              <a href="#about" className="transition hover:text-[hsl(var(--secondary))]" data-testid="link-footer-about">About RP</a>
              <a href="#services" className="transition hover:text-[hsl(var(--secondary))]" data-testid="link-footer-services">Services</a>
              <a href="#areas" className="transition hover:text-[hsl(var(--secondary))]" data-testid="link-footer-areas">Areas we cover</a>
              <a href="#contact" className="transition hover:text-[hsl(var(--secondary))]" data-testid="link-footer-contact">Make an enquiry</a>
            </div>
          </div>
          <div>
            <h3 className="text-xs font-bold uppercase tracking-[.16em] text-[hsl(var(--secondary))]">Get in touch</h3>
            <div className="mt-5 flex flex-col gap-3 text-sm text-[hsl(var(--primary-foreground)/.68)]">
              <a href={phoneHref} className="flex items-center gap-2 transition hover:text-[hsl(var(--secondary))]" data-testid="link-footer-phone"><Phone className="h-4 w-4" /> {contactPhone}</a>
              <a href={whatsappHref} target="_blank" rel="noreferrer" className="flex items-center gap-2 transition hover:text-[hsl(var(--secondary))]" data-testid="link-footer-whatsapp"><MessageCircle className="h-4 w-4" /> WhatsApp</a>
              <a href={mapHref} target="_blank" rel="noreferrer" className="flex items-start gap-2 transition hover:text-[hsl(var(--secondary))]" data-testid="link-footer-map"><MapPin className="mt-0.5 h-4 w-4 shrink-0" /> {businessAddress}</a>
            </div>
          </div>
        </div>
        <div className="border-t border-[hsl(var(--primary-foreground)/.12)]">
          <div className="mx-auto flex max-w-[1240px] flex-col gap-2 px-5 py-5 text-[11px] text-[hsl(var(--primary-foreground)/.45)] sm:flex-row sm:items-center sm:justify-between lg:px-10">
            <span>© RP Real Estate · Ahmedabad, Gujarat</span>
            <span>Industrial real estate agency · Open 24 hours</span>
          </div>
        </div>
      </footer>
    </main>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;